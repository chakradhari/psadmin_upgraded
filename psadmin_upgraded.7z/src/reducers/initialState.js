export default {
  authors: [],
  courses: []
}
